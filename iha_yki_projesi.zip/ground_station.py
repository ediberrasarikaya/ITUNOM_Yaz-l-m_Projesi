
import argparse
import socket
import threading
import time
import sys
import cv2

from common import json_loads_line, recv_packed_frame

class YerKontrolIstasyonu:
    def __init__(self, telemetry_host: str, telemetry_port: int, video_host: str, video_port: int, show_video: bool = True):
        self.telemetry_host = telemetry_host
        self.telemetry_port = telemetry_port
        self.video_host = video_host
        self.video_port = video_port
        self.show_video = show_video

        self.running = False
        self.telemetry_latest = {}

        # UDP alıcı
        self.udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.udp.bind((self.telemetry_host, self.telemetry_port))
        self.udp.settimeout(1.0)

    def start(self):
        self.running = True
        print(f"[YKI] Telemetry UDP listening on {self.telemetry_host}:{self.telemetry_port}")
        print(f"[YKI] Video TCP connecting to {self.video_host}:{self.video_port}")

        self.telemetry_thread = threading.Thread(target=self._telemetry_loop, daemon=True)
        self.ui_thread = threading.Thread(target=self._ui_loop, daemon=True)
        self.telemetry_thread.start()
        self.ui_thread.start()

        self.video_thread = None
        if self.show_video:
            self.video_thread = threading.Thread(target=self._video_loop, daemon=True)
            self.video_thread.start()

        try:
            while self.running:
                time.sleep(0.2)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()

    def stop(self):
        self.running = False
        try:
            self.udp.close()
        except:
            pass
        cv2.destroyAllWindows()
        print("\n[YKI] Stopped.")

    # ---- Internal loops ----
    def _telemetry_loop(self):
        buf = b""
        while self.running:
            try:
                data, addr = self.udp.recvfrom(8192)
            except socket.timeout:
                continue
            if not data:
                continue
            # satır sonuna göre ayır
            lines = data.split(b"\n")
            for line in lines:
                if not line.strip():
                    continue
                try:
                    obj = json_loads_line(line)
                    self.telemetry_latest = obj
                except Exception as e:
                    # bozuk paket
                    continue

    def _video_loop(self):
        # TCP client
        import socket as sk
        s = sk.socket(sk.AF_INET, sk.SOCK_STREAM)
        try:
            s.connect((self.video_host, self.video_port))
        except OSError as e:
            print(f"[YKI] Video connect failed: {e}")
            return

        print("[YKI] Video connected. Press 'q' to close video window.")
        while self.running:
            try:
                frame = recv_packed_frame(s)
            except Exception as e:
                print(f"[YKI] Video recv ended: {e}")
                break
            cv2.imshow("YKI Video", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.show_video = False
                break
        s.close()

    def _ui_loop(self):
        # Basit CLI güncelleme
        while self.running:
            tlm = self.telemetry_latest
            if tlm:
                msg = (
                    f"\rTS: {tlm.get('timestamp','--')} | "
                    f"Pos(x,y,z): {tlm.get('position',{}).get('x','--')}, "
                    f"{tlm.get('position',{}).get('y','--')}, "
                    f"{tlm.get('position',{}).get('z','--')} | "
                    f"Alt: {tlm.get('altitude_m','--')} m | "
                    f"Speed: {tlm.get('speed_mps','--')} m/s | "
                    f"Batt: {tlm.get('battery_pct','--')} %   "
                )
                sys.stdout.write(msg)
                sys.stdout.flush()
            time.sleep(0.1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--telemetry-host", default="0.0.0.0", help="UDP bind host for telemetry (default: 0.0.0.0)")
    ap.add_argument("--telemetry-port", type=int, default=5005, help="UDP port for telemetry (default: 5005)")
    ap.add_argument("--video-host", required=True, help="Video TCP server host (simulator side)")
    ap.add_argument("--video-port", type=int, default=6000, help="Video TCP server port (default: 6000)")
    ap.add_argument("--no-video", action="store_true", help="Disable video window")
    args = ap.parse_args()

    yki = YerKontrolIstasyonu(args.telemetry_host, args.telemetry_port, args.video_host, args.video_port, show_video=not args.no_video)
    yki.start()

if __name__ == "__main__":
    main()
