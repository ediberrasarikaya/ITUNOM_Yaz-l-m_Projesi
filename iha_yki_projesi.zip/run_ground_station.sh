
#!/usr/bin/env bash
python3 ground_station.py --telemetry-host 127.0.0.1 --telemetry-port 5005 --video-host 127.0.0.1 --video-port 6000
