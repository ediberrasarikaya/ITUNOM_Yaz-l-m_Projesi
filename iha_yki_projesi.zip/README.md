
# İHA Simülatörü & Yer Kontrol İstasyonu (CLI)

Bu proje, ödevinizin **Uygulama Kısmı** için örnek bir başlangıç setidir. İki ayrı Python uygulamasından oluşur:

1) **İHA Simülatörü** (`simulator.py`): 
   - Telemetri verilerini (x,y,z, hız, irtifa, pil, zaman damgası) **UDP** ile periyodik olarak yayınlar.
   - Kameradan aldığı görüntüyü JPEG'e çevirip uzunluk-prefiksli paketlerle **TCP** üzerinden YKİ'ye yollar.
   - Telemetri ve görüntü akışı **iki ayrı thread** ile **eşzamanlı** yönetilir (multithreading).
   - Kamera yoksa sentetik görüntü üretme seçeneği vardır.

2) **Yer Kontrol İstasyonu (YKİ)** (`ground_station.py`):
   - UDP üzerinden gelen telemetri JSON paketlerini alır ve **CLI üzerinde canlı günceller**.
   - TCP üzerinden gelen video akışını bir pencerede gösterir (*OpenCV gerekli*).
   - Alım tarafında da telemetri ve video **ayrı thread**'lerle yönetilir.

## Mimari ve Tasarım (OOP + Threading + Ağ)
- Her uygulama tek bir **ana sınıf** etrafında kurgulanmıştır: `IHASimulator` ve `YerKontrolIstasyonu`.
- Her bir akış (telemetri / video) için **ayrı iş parçacığı (thread)** başlatılır.
- UDP telemetri, gecikme ve paket kaybına daha toleranslıdır; TCP video akışı veriyi sıralı ve tam iletmeyi garanti eder.
- Video paketleri **[4 byte big-endian uzunluk] + [JPEG bytes]** formatında gönderilir.
- Telemetri paketleri **UTF-8 JSON** olarak gönderilir.

## Bağımlılıklar
```bash
pip install -r requirements.txt
```
- `opencv-python`
- `numpy`

## Hızlı Başlangıç (Aynı Bilgisayarda)
İki terminal açın.

### Terminal 1 — YKİ (önce alıcıyı başlatıyoruz)
```bash
python ground_station.py --telemetry-host 127.0.0.1 --telemetry-port 5005 --video-host 127.0.0.1 --video-port 6000
```

### Terminal 2 — İHA Simülatörü
Gerçek kamera ile:
```bash
python simulator.py --send-telemetry-to 127.0.0.1:5005 --video-bind 0.0.0.0:6000 --use-camera
```
Kamera yoksa (sentetik görüntü):
```bash
python simulator.py --send-telemetry-to 127.0.0.1:5005 --video-bind 0.0.0.0:6000
```

> **Not:** Windows'ta `--use-camera` ile çalışırken kamera erişim izniniz olduğundan emin olun. Linux/macOS'ta da kamera sürücüleriniz yüklü olmalıdır.

## Dosyalar
- `common.py`: Ortak yardımcılar (JSON gönderimi, video paketleme).
- `simulator.py`: İHA simülatör sınıfı ve CLI argümanları.
- `ground_station.py`: YKİ sınıfı ve CLI argümanları.
- `requirements.txt`: Gerekli Python paketleri.
- `run_simulator.bat/.sh`, `run_ground_station.bat/.sh`: Örnek çalışma komutları.

## Geliştirme Fikirleri (Ödevi Zenginleştirmek İçin)
- **Filtreleme:** Gelen telemetriyi hareketli ortalama veya basit bir düşük geçiren filtre ile yumuşatma.
- **Kayıt:** Telemetriyi `.csv` olarak kaydetme, video karelerini periyodik olarak `.jpg` yazma.
- **Komutlar:** YKİ tarafında klavye girdisi ile İHA'ya (simülatöre) basit komutlar (örn. hız değişimi) gönderme.
- **Güvenlik:** Basit bir kimlik doğrulama veya paket imzası ekleme.
- **Hata Toleransı:** TCP bağlantı düşerse yeniden bağlanmayı deneme, UDP paket sırası ve gecikme ölçümü.

## Sorun Giderme
- **Video penceresi açılmıyor:** Uzaktan masaüstü kullanıyorsanız OpenCV GUI sorun çıkarabilir. Konsolda sadece telemetriyle test edebilirsiniz (`--no-video` opsiyonu ekleyebilirsiniz).
- **Kamera erişim hatası:** `--use-camera` devredeyken `cv2.VideoCapture(0)` başarısız olabilir. Sürücü/izinleri kontrol edin ya da sentetik moda geçin.
- **Bağlantı hatası:** Önce YKİ'yi açın, sonra simülatörü; video için TCP sunucusu simülatördedir, YKİ client'tır.
