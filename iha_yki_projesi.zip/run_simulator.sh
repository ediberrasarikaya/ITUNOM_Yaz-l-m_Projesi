
#!/usr/bin/env bash
python3 simulator.py --send-telemetry-to 127.0.0.1:5005 --video-bind 0.0.0.0:6000 --use-camera
