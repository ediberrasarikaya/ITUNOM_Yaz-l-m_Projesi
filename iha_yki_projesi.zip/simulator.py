
import argparse
import json
import socket
import threading
import time
import random
from datetime import datetime
import cv2
import numpy as np

from common import json_dumps_telemetry, encode_frame_to_jpeg_bytes, pack_frame

class IHASimulator:
    def __init__(self, telemetry_host: str, telemetry_port: int, video_bind_host: str, video_bind_port: int, use_camera: bool = False, fps: int = 15):
        self.telemetry_host = telemetry_host
        self.telemetry_port = telemetry_port
        self.video_bind_host = video_bind_host
        self.video_bind_port = video_bind_port
        self.use_camera = use_camera
        self.fps = fps

        # Simüle edilen durum değişkenleri
        self.x, self.y, self.z = 0.0, 0.0, 10.0  # metre
        self.vx, self.vy, self.vz = 1.0, 0.5, 0.0  # m/s
        self.speed = 2.0  # m/s (yaklaşık)
        self.altitude = 10.0  # metre
        self.battery = 100.0  # yüzde
        self.running = False

        # Ağ soketleri
        self.udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        # Kamera veya sentetik
        self.cap = None

    def start(self):
        self.running = True

        # TCP video sunucusunu bind + listen yap
        self.tcp.bind((self.video_bind_host, self.video_bind_port))
        self.tcp.listen(1)
        print(f"[SIM] Video TCP server listening on {self.video_bind_host}:{self.video_bind_port}")

        # Thread'ler
        self.telemetry_thread = threading.Thread(target=self._telemetry_loop, daemon=True)
        self.video_thread = threading.Thread(target=self._video_loop, daemon=True)

        self.telemetry_thread.start()
        self.video_thread.start()

        try:
            while self.running:
                time.sleep(0.2)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()

    def stop(self):
        self.running = False
        try:
            self.udp.close()
        except:
            pass
        try:
            self.tcp.close()
        except:
            pass
        if self.cap is not None:
            self.cap.release()
        print("[SIM] Stopped.")

    # ---- Internal loops ----
    def _telemetry_loop(self):
        period = 0.2  # 5 Hz
        print(f"[SIM] Telemetry sender to {self.telemetry_host}:{self.telemetry_port} @ 5Hz")
        while self.running and self.battery > 0:
            t0 = time.time()

            # basit hareket modeli
            self.x += self.vx * period
            self.y += self.vy * period
            # z/altitude aynı kalsın ya da hafif dalgalansın
            self.altitude = 10.0 + 0.5 * random.uniform(-1, 1)
            self.speed = (self.vx**2 + self.vy**2 + self.vz**2) ** 0.5

            # pil azalması
            self.battery = max(0.0, self.battery - 0.02)

            payload = {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "position": {"x": round(self.x, 2), "y": round(self.y, 2), "z": round(self.z, 2)},
                "altitude_m": round(self.altitude, 2),
                "speed_mps": round(self.speed, 2),
                "battery_pct": round(self.battery, 2)
            }
            data = json_dumps_telemetry(payload)
            self.udp.sendto(data, (self.telemetry_host, self.telemetry_port))

            # periyodu koru
            dt = time.time() - t0
            rem = period - dt
            if rem > 0:
                time.sleep(rem)

        print("[SIM] Telemetry loop ended (battery empty or stopped).")

    def _video_loop(self):
        # TCP client kabul et
        print("[SIM] Waiting for YKI video client...")
        self.tcp.settimeout(1.0)
        conn = None
        while self.running:
            try:
                conn, addr = self.tcp.accept()
                print(f"[SIM] Video client connected from {addr}")
                break
            except socket.timeout:
                continue
        if conn is None:
            print("[SIM] Video loop ended (no client).")
            return

        # Kamera
        if self.use_camera:
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                print("[SIM] WARNING: Camera open failed. Switching to synthetic frames.")
                self.cap = None

        period = 1.0 / max(1, self.fps)
        t0 = time.time()
        frame_idx = 0

        try:
            while self.running:
                if self.cap is not None:
                    ret, frame = self.cap.read()
                    if not ret:
                        print("[SIM] Camera read failed, switching to synthetic.")
                        self.cap.release()
                        self.cap = None
                        frame = None
                else:
                    # sentetik kare (basit overlay)
                    frame = self._synthetic_frame(640, 360, frame_idx)

                jpeg = encode_frame_to_jpeg_bytes(frame, quality=75)
                pkt = pack_frame(jpeg)
                conn.sendall(pkt)

                frame_idx += 1
                # FPS sabitleme
                dt = time.time() - t0
                t0 = time.time()
                sleep_time = period - dt
                if sleep_time > 0:
                    time.sleep(sleep_time)
        except (BrokenPipeError, ConnectionResetError):
            print("[SIM] Video client disconnected.")
        finally:
            conn.close()

    def _synthetic_frame(self, w, h, i):
        # BGR
        frame = np.zeros((h, w, 3), dtype=np.uint8)
        # hareket eden bir kare
        size = 60
        x = (i * 5) % (w - size)
        y = (i * 3) % (h - size)
        cv2.rectangle(frame, (x, y), (x+size, y+size), (0, 255, 0), -1)

        # telemetri overlay
        text = f"x={self.x:.1f} y={self.y:.1f} alt={self.altitude:.1f}m batt={self.battery:.1f}%"
        cv2.putText(frame, text, (10, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2, cv2.LINE_AA)
        return frame

def parse_host_port(arg: str):
    if ":" not in arg:
        raise ValueError("Use HOST:PORT format")
    host, port = arg.split(":", 1)
    return host, int(port)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--send-telemetry-to", required=True, help="UDP target HOST:PORT (e.g., 127.0.0.1:5005)")
    ap.add_argument("--video-bind", required=True, help="TCP bind HOST:PORT (e.g., 0.0.0.0:6000)")
    ap.add_argument("--use-camera", action="store_true", help="Use real webcam for video")
    ap.add_argument("--fps", type=int, default=15, help="Video FPS")
    args = ap.parse_args()

    thost, tport = parse_host_port(args.send_telemetry_to)
    vhost, vport = parse_host_port(args.video_bind)

    sim = IHASimulator(thost, tport, vhost, vport, use_camera=args.use_camera, fps=args.fps)
    sim.start()

if __name__ == "__main__":
    main()
