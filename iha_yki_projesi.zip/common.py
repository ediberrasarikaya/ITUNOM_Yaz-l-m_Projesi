
import json
import struct
import cv2
import numpy as np

# ---- JSON helpers ----
def json_dumps_telemetry(payload: dict) -> bytes:
    return (json.dumps(payload) + "\n").encode("utf-8")

def json_loads_line(line: bytes) -> dict:
    return json.loads(line.decode("utf-8").strip())

# ---- Video (frame) helpers ----
def encode_frame_to_jpeg_bytes(frame, quality: int = 80) -> bytes:
    # frame: BGR (OpenCV)
    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)]
    ok, buf = cv2.imencode(".jpg", frame, encode_param)
    if not ok:
        raise RuntimeError("JPEG encode failed")
    return buf.tobytes()

def pack_frame(jpeg_bytes: bytes) -> bytes:
    # 4-byte big-endian length prefix + payload
    return struct.pack(">I", len(jpeg_bytes)) + jpeg_bytes

def read_exact(sock, n: int) -> bytes:
    # blocking exact read
    data = b""
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk:
            raise ConnectionError("Socket closed")
        data += chunk
    return data

def recv_packed_frame(sock):
    header = read_exact(sock, 4)
    (length,) = struct.unpack(">I", header)
    payload = read_exact(sock, length)
    arr = np.frombuffer(payload, dtype=np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if frame is None:
        raise RuntimeError("JPEG decode failed")
    return frame
